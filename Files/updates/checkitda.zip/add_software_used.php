<?php session_start();
ob_start();
$page = "softwareused";
$side_menu="addsoftwareused";
include "inc/session_check.php";
//print_r($_POST);
if(isset($_POST['submit']))
{
	$software_used = $_POST['software_used'];
	$status = $_POST['status'];
	$stream = $_POST['stream'];
	
	echo "select * from sys_software_used where software_used like '%$software_used%'";
	//exit;475
	
	$selcourse=mysql_query("select * from sys_software_used where course_title like '%$software_used%'");
	if($rescourse=mysql_fetch_array($selcourse))
	{
		header("location: list_software_used.php?msg=err&cont=Name already Exist");
		
	}else
		{
	 $ins="insert into sys_software_used(software_used,main_stream,status) values('$software_used','$stream','$status')";
				
	if(mysql_query($ins))
{
	header("location: list_software_used.php?msg=succ&cont=Software Used  added");
}
else
	{
		header("location: list_software_used.php?msg=err&cont=Error in insert query");
	}


}
}
?>


<!DOCTYPE html>
  <!--[if lt IE 7]>
    <html class="lt-ie9 lt-ie8 lt-ie7" lang="en">
  <![endif]-->

  <!--[if IE 7]>
    <html class="lt-ie9 lt-ie8" lang="en">
  <![endif]-->

  <!--[if IE 8]>
    <html class="lt-ie9" lang="en">
  <![endif]-->

  <!--[if gt IE 8]>
    <!-->
    <html lang="en">
    <!--
  <![endif]-->

  <head>
    <meta charset="utf-8">
    <title>Synergy admin</title>
     <link href="icomoon/style.css" rel="stylesheet">
    <!--[if lte IE 7]>
      <script src="css/icomoon-font/lte-ie7.js"></script>
    <![endif]-->
    <link href="css/main.css" rel="stylesheet">
    

  </head>
  <body>
    
    <?php 
	  	include "inc/header.php";
    ?>

    <div class="container-fluid">
      
    <?php 
	  	include "inc/main_nav.php";
    ?>
      
      <div class="dashboard-wrapper">
        <div class="main-container">
        
          <?php 
		  	include "inc/sub_navbar.php";
			include "inc/breadcrumb.php";
		  ?>

			<div class="row-fluid">
            <div class="span6">
              <div class="widget">
                <div class="widget-header">
                  <div class="title">
                 Add Software Used
                  </div>
                </div>
                <div class="widget-body">
                	<?php include 'message.php'; ?>
                	<form class="form-horizontal no-margin well" id="ad_form" name="form" method="post">
	            	 
                     <div class="control-group">
                      <label class="control-label">
                        Stream : 
                      </label>
                      <div class="controls">
                       <select name="stream" class="required span4">
					<option value="">--Select--</option>
					<?php
						$qy = "SELECT * FROM ccts_main_stream where status='1'";
						$exec = mysql_query($qy);
						while($val = mysql_fetch_array($exec)){
							echo '<option value="'.$val['id'].'">'.$val['stream'].'</option>';
						}
					?>
				</select>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                 Software Used :
                      </label>
                      <div class="controls">
                       <input class="required span4" type="text" name="software_used" value="">
                      </div>
                    </div>
                    
                    
                     <div class="control-group">
                      <label class="control-label">
                        Status : 
                      </label>
                      <div class="controls">
                       <select name="status" class="required span4">
					<option value="">--Select--</option>
					<option value="1">Active</option>
					<option value="0">Inactive</option>
				</select>
                      </div>
                    </div>
	
				   
					 <div class="form-actions no-margin">
				 	<input type="submit" class="btn btn-info" name="submit" value="submit">
                    </div>
			</form>
				</div>
              </div>
            </div>

            
          </div>

          
        </div>
      </div>
    </div>
    
    <?php
    include 'inc/footer.php';
    ?>
  
   <script src="js/wysiwyg/wysihtml5-0.3.0.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/wysiwyg/bootstrap-wysihtml5.js"></script>
    <script type="text/javascript"  src="js/jquery-latest.js"></script>
<script type="text/javascript"  src="js/jquery.validate.js"></script>
<script>
  $(document).ready(function(){
    $("#ad_form").validate({
    	success: function(label) {
			// set &nbsp; as text for IE
			label.html("&nbsp;").addClass("checked");
		}
    });
    $("#advert_pos").change(function(){
    	var posid = $(this).val();
    	dataString = "posid="+posid;
    	$.ajax({
    	type: "POST",
    	url: "get_ad_size.php",
    	data: dataString,
    	success: function(html){
    		$("#advert_size").html(html);
    	}
    	})
    });
    });
</script>
</body>
</html>
