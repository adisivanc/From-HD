<?php 

$host = "localhost";
$user = "root";
$pass = "";
$db_name = "synergys_synergydb";


mysql_connect($host,$user,$pass);
mysql_select_db($db_name);
?>