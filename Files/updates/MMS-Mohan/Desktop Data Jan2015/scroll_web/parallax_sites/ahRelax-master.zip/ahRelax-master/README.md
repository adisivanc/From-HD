ahrelax
=======

Experimental lightweight JS/jQuery script to facilitate quick scroll based animations.   

Currently less than 1kb minified, but will probably need to grow to be useful.

Tried to make use of some of the tips in here, without making it as complicated:
https://medium.com/@dhg/parallax-done-right-82ced812e61c