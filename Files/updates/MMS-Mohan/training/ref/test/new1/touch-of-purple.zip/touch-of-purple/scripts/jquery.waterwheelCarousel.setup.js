$(document).ready(function () {
  $("#waterwheelCarousel").waterwheelCarousel("horizontal",{
	  // include options like this:
	  // (use quotes only for string values, and no trailing comma after last option)
	  // option: value,
	  // option: value
	  startingItem: 6
  });
});