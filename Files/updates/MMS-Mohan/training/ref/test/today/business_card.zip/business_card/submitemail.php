<?php

/************************
* Variables you can change
*************************/

$mailto = "you@email.com"; // Enter your mail addres here. 
$cc = "";
$bcc = "";
$subject = "Email subject"; // Enter the subject here.

$vname = ucwords($_POST['name']); // Displays entered name in the "From" field of the e-mail.
								  // Replace with "Website contact form" etc (with quotes!) if 
								  // you don't want to display the name.


/************************
* do not modify anything below unless you know PHP/HTML/XHTML
*************************/


$email = $_POST['email'];

function validateEmail($email)
{
   if(eregi('^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,4}(\.[a-zA-Z]{2,3})?(\.[a-zA-Z]{2,3})?$', $email))
	  return true;
   else
	  return false;
}


if((strlen($_POST['name']) < 1 ) || (strlen($email) < 1 ) || (strlen($_POST['question']) < 1 ) || validateEmail($email) == FALSE){
	$emailerror .= '';

	if(strlen($_POST['name']) < 1 ){
		$emailerror .= '<span class="wrong">Please enter your name.</span>';
	}

	if(strlen($email) < 1 ){
		$emailerror .= '<span class="wrong">Please enter your e-mail address.</span>';
	}

	if(validateEmail($email) == FALSE) {
		$emailerror .= '<span class="wrong">Please enter a valid e-mail address.</span>';
	}

	if(strlen($_POST['question']) < 1 ){
		$emailerror .= '<span class="wrong">Please enter your message.</span>';
	}

} else {

	$emailerror .= "<span>Your message has been sent successfully. Thank you!</span>";



	// NOW SEND THE ENQUIRY

	$timestamp = date("F j, Y, g:ia");

	$messageproper ="\n\n" .
		"Name: " .
		ucwords($_POST['name']) .
		"\n" .
		"Email: " .
		$email .
		"\n" .
		"Subject: " .
		$_POST['subject'] .
		"\n" .
		"Comments: " .
		"\n" .
		$_POST['question'] .
		"\n" .
		"\n\n" ;

		$messageproper = trim(stripslashes($messageproper));
		mail($mailto, $subject, $messageproper, "From: \"$vname\" <".$_POST['email'].">\nReply-To: \"".ucwords($_POST['first_name'])."\" <".$_POST['email'].">\nX-Mailer: PHP/" . phpversion() );

}
?>

<?php echo $emailerror; // Displays the error/success message. ?>

