Cufon.replace('.menu li', { fontFamily: 'Myriad Pro Regular', hover:true });
Cufon.replace('h3', { fontFamily: 'Myriad Pro', hover:true });
