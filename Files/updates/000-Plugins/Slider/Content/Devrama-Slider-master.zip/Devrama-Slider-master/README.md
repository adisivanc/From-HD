Devrama Image/HTML Slider - jQuery Plugin
============

'Devrama Slider' is a image slider with many features.

It support both images and HTML contents.

'Responsive'

'CSS3 Transition Ready'

'Transition Effects'

'Progress Bar'

'HTML content inside a slide'

'Advanced Preload/Lazyload'

'Single Javascript file'

'CSS Customizable'

'User defined Navigation/Control available'

'Pause on hover'.


HOW TO USE IT
---------------

[http://devrama.com/static/devrama-slider/](http://devrama.com/static/devrama-slider/)



LICENSE
---------
Copyright 2014 Devrama.com

Licensed under the MIT license:
http://www.opensource.org/licenses/mit-license.php
