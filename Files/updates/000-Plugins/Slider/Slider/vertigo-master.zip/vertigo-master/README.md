# vertigo
Jquery Vertical Content Slider Plugin

demo: http://www.jenaldesign.com/vertigo

    $(document).ready( function($) {
        $('#news').vertigo();     
    });
    
	<ul id="news">
		<li>Anything</li>
		<li>Anything</li>
		<li>Anything</li>
	</ul>


Options:

	play: true or false (Automatic slide)

	timer: Timer for each slide
