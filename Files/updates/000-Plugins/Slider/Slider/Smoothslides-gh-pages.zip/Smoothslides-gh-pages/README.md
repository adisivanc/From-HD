#Smoothslides
A responsive jQuery slideshow with beautiful Ken Burns type effects on each image. Created by <a href="https://twitter.com/kthornbloom" target="_blank">Kevin Thornbloom</a>
<br>
<a href="http://kthornbloom.github.io/Smoothslides/" target="_blank">Demo & Docs</a>

#Updates

V2.2.0
* New option - order
* New option - effectModifier
* Ability to set certain effects on certain images

V2.1.0
* New option - matchImageSize
* Adding limited support for IE8
