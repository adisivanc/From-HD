Off-Canvas Menu Effects
=========

Some inspiration for off-canvas menu effects and styles using CSS transitions and SVG path animations. 

[Article on Codrops](http://tympanus.net/codrops/?p=20100)

[Demo](http://tympanus.net/Development/OffCanvasMenuEffects/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

[© Codrops 2014](http://www.codrops.com)