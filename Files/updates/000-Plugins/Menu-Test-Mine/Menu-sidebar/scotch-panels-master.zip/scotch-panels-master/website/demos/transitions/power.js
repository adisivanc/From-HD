$(function() {

    $('.scotch-panel').scotchPanel({
        containerSelector: 'section',
        direction: 'left',
        duration: 2000,
        distanceX: '100%',
        enableEscapeKey: true
    });

});