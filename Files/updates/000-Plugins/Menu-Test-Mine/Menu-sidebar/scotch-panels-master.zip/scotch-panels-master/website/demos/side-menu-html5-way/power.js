$(function() {

    $('#scotch-panel').scotchPanel();

});