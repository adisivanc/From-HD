mobile-menu
===========

JQuery Simple Mobile Nav
by Craig Bauer

This is about as simple as you can get. Jquery Simple Mobile Nav uses the slide toggle effect when clicking on the $('#open') object. Click to open and again to close it.

This is easily customizable through the css file. Change colors, fonts and padding, etc...

Tweek the css or add your own.

Enjoy

