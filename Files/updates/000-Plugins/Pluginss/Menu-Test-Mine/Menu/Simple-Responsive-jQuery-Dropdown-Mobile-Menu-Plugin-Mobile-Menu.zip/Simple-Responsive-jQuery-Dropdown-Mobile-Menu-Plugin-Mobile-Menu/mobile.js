//The Document is loaded
$(document).ready(function() {

	//Mobile Menu Script
	$('#open').click(function() {

		$('#m-nav').slideToggle(1000); // Change the the speed of the animation. 1000 = 1 second.

	});

});
	
