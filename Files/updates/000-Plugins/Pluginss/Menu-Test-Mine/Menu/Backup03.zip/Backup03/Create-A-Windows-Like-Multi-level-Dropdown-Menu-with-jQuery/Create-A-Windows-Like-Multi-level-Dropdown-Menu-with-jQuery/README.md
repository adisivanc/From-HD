jQuery Main Menu
================

jQuery plugin that transform HTML list to Windows like main menu
