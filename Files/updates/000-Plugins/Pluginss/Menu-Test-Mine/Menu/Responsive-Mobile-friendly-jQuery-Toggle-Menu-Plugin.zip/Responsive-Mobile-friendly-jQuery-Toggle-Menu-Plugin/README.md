Responsive-mobile-first-navigation-bar
======================================

This project uses jQuery and CSS to create a mobile-first navigation bar with minimal impact.
There's really not much more to it. As its stands its mostly a one-trick pony.

Future development will focus on:

1) making it easy to install

2) making it lightweight and quick

3) improving cross-platform compatibility

Feel free to contribute. 
