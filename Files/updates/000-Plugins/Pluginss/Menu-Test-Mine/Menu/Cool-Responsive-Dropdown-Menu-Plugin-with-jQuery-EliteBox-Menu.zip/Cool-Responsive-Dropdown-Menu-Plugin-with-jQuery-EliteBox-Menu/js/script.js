/*jshint curly: false, quotmark: true*/
/*
	Programmer: Lukasz Czerwinski
	CodeCanyon: http://codecanyon.net/user/Lukasz_Czerwinski
	 
	Library version: jQuery 1.7+ and jQuery UI 

	If this script you like, please put a comment on codecanyon.
	
*/
jQuery(document).ready(function($){ 
  //Default usage 
  $(".eliteBoxMenu ul").eliteBoxMenu({
      mainWidth: 188
  }); 
}); 
