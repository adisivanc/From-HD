$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+858081+'&oi='+2138+'&ot=1&&url='+window.location, function(json){})    

});