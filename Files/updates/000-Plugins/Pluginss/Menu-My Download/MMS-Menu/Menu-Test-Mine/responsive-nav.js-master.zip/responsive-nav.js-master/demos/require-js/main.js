require(["../../responsive-nav"], function() {
    var navigation = responsiveNav(".nav-collapse");
});
