

 1. Download skins for Flow Slider at http://www.flowslider.com/skins
 
 2. Copy-paste the skin folder into this folder
 
 3. Go to the skin folder and open *.html files for preview
 