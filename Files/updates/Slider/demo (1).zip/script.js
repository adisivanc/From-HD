$(document).ready(function(){
	
	$("#slider").mopSlider({
		'w':800,
		'h':150,
		'sldW':500,
		'btnW':200,
		'itemMgn':20,
		'indi':"Slide To View More",
		'type':'tutorialzine',
		'shuffle':0
	});
	
});