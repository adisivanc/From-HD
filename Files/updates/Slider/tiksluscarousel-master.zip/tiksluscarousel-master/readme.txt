TikslusCarousel version 2.0.0(released 3 june 2014)
===================================================

Tikslus carousel is a jquery based fully responsive image carousel with following features:

Fully Responsive
Can be used without providing width and height of the images
Support custom animation Via CSS3 classes
Can be used with Jquery Mobile plugin



New in version 2.0.0 
============================

1. Pause/resume support.
2. Switch to full screen view.
3. Introducing Navigation Icons.
4. Thumbnails based navigation.
5. Zoom-in Zoom-out Effect.
6. Displays Number of current Slide playing.


We have put all the plugins files in Plugins folder.
You can use Plugins folder directly in your projects.

Visit http://tikslus.com/tiksluscarousel/demo for demo
visit http://tikslus.com/tiksluscarousel/docs for plugin documentation
